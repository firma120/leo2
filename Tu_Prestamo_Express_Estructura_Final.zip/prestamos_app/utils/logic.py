
import pandas as pd
from openpyxl import Workbook

def init_db(path):
    wb = Workbook()
    ws1 = wb.active
    ws1.title = "Clientes"
    ws1.append(["ID", "Cédula", "Nombres", "Celular", "Correo", "Fecha Préstamo", "Fecha Final", "Valor", "Cuotas", "Estado"])
    ws2 = wb.create_sheet("Pagos")
    ws2.append(["ID Cliente", "Fecha Pago", "Cuota", "Monto", "Saldo Restante"])
    wb.save(path)
