
import streamlit as st
from openpyxl import load_workbook

def registrar_pago(db_path):
    st.subheader("📥 Registro de Pago")
    wb = load_workbook(db_path)
    clientes_ws = wb["Clientes"]
    pagos_ws = wb["Pagos"]
    clientes = [(row[0].value, row[2].value) for row in clientes_ws.iter_rows(min_row=2) if row[9].value == "Activo"]

    if not clientes:
        st.warning("No hay préstamos activos.")
        return

    cliente = st.selectbox("Selecciona un cliente", clientes, format_func=lambda x: f"{x[0]} - {x[1]}")
    cliente_id = cliente[0]
    pagos = [row for row in pagos_ws.iter_rows(min_row=2, values_only=True) if row[0] == cliente_id and row[4] > 0]

    if not pagos:
        st.success("✅ Este cliente ya ha pagado todas las cuotas.")
        return

    cuota = pagos[0]
    st.info(f"🔔 Próxima cuota a pagar: Fecha: {cuota[1]} - Cuota #{cuota[2]} - Valor: ${cuota[3]:,.0f}")

    if st.button("Registrar Pago"):
        for row in pagos_ws.iter_rows(min_row=2):
            if row[0].value == cliente_id and row[2].value == cuota[2]:
                row[4].value = 0
                break

        saldo_total = sum(row[4].value for row in pagos_ws.iter_rows(min_row=2) if row[0].value == cliente_id)
        if saldo_total == 0:
            for row in clientes_ws.iter_rows(min_row=2):
                if row[0].value == cliente_id:
                    row[9].value = "Finalizado"
                    break

        wb.save(db_path)
        st.success("✅ Pago registrado correctamente.")
