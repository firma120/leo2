
import streamlit as st
from datetime import datetime, timedelta
from openpyxl import load_workbook

def registrar_prestamo(db_path):
    st.subheader("💰 Registro de Préstamo")
    wb = load_workbook(db_path)
    ws = wb["Clientes"]
    clientes = [(row[0].value, row[2].value) for row in ws.iter_rows(min_row=2) if row[9].value == "Activo"]

    if not clientes:
        st.warning("No hay clientes activos registrados.")
        return

    cliente_seleccionado = st.selectbox("Selecciona un cliente", clientes, format_func=lambda x: f"{x[0]} - {x[1]}")
    valor = st.number_input("Valor del préstamo (máx. $500.000)", max_value=500000, min_value=10000, step=10000)
    cuotas = st.selectbox("Número de cuotas (quincenales)", [1, 2, 3, 4])
    fecha_inicio = st.date_input("Fecha del préstamo", datetime.today())

    if st.button("Registrar Préstamo"):
        cliente_id = cliente_seleccionado[0]
        fecha_final = fecha_inicio + timedelta(days=15 * (cuotas - 1))
        interes_total = round(valor * 0.15 * (cuotas / 2), 2)
        total_a_pagar = valor + interes_total
        cuota_valor = round(total_a_pagar / cuotas, 2)

        for row in ws.iter_rows(min_row=2):
            if row[0].value == cliente_id:
                row[5].value = fecha_inicio.strftime("%Y-%m-%d")
                row[6].value = fecha_final.strftime("%Y-%m-%d")
                row[7].value = valor
                row[8].value = cuotas
                break

        pagos_ws = wb["Pagos"]
        saldo = total_a_pagar
        for i in range(cuotas):
            fecha_pago = fecha_inicio + timedelta(days=15 * i)
            pagos_ws.append([cliente_id, fecha_pago.strftime("%Y-%m-%d"), i + 1, cuota_valor, round(saldo - cuota_valor * (i + 1), 2)])

        wb.save(db_path)
        st.success(f"✅ Préstamo registrado. Total a pagar: ${total_a_pagar:,} en {cuotas} cuotas de ${cuota_valor:,}")
