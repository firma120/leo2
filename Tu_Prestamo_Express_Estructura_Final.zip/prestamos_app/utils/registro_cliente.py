
import streamlit as st
from openpyxl import load_workbook

def registrar_cliente(db_path):
    st.subheader("🧾 Registro de Cliente")
    cedula = st.text_input("Cédula", max_chars=15)
    nombres = st.text_input("Nombres completos")
    celular = st.text_input("Celular", max_chars=15)
    correo = st.text_input("Correo (opcional)")

    if st.button("Registrar Cliente"):
        if not cedula or not nombres or not celular:
            st.warning("Por favor, completa todos los campos obligatorios.")
            return
        wb = load_workbook(db_path)
        ws = wb["Clientes"]
        for row in ws.iter_rows(min_row=2, values_only=True):
            if row[1] == cedula:
                st.error("⚠️ Ya existe un cliente con esta cédula.")
                return
        new_id = ws.max_row
        ws.append([new_id, cedula, nombres, celular, correo, "", "", "", "", "Activo"])
        wb.save(db_path)
        st.success("✅ Cliente registrado exitosamente.")
